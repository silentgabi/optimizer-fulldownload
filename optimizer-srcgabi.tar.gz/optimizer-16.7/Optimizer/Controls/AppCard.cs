﻿using System.Windows.Forms;

namespace Optimizer
{
    public sealed partial class AppCard : UserControl
    {
        public AppCard()
        {
            InitializeComponent();
        }
    }
}
